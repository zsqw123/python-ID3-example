使用python模块如下:
    numpy
    pandas
    math
    operator
    matplotlib

主程序为show_tree.py
导入的数据为input.csv(逗号分隔符样式表格)
输出结果为output.pdf